const axios = require('axios');

const BASE_URL = 'http://localhost:3000/api';
let tokens = {};
let userData = {};
let tripData = {};
let bookingData = {};

// ✅ NOUVELLES DONNÉES DE TEST UNIQUES
const testUsers = {
  driver: {
    email: `laddy.driver.${Date.now()}@test.com`, // ✅ Email unique avec timestamp
    password: 'SecurePass456!',
    displayName: 'laddy Conductrice',
    firstName: 'laddy',
    lastName: 'Dubois',
    gender: 'femme',
    phone: '0612345678'
  },
  passenger: {
    email: `reinitha.passenger.${Date.now()}@test.com`, // ✅ Email unique avec timestamp
    password: 'SecurePass789!',
    displayName: 'reinitha Passagère',
    firstName: 'reinitha',
    lastName: 'Martin',
    gender: 'femme',
    phone: '0687654321'
  }
};

// ✅ NOUVEAU TRAJET DIFFÉRENT
const testTrip = {
  departure: {
    city: 'Lyon',
    address: 'Gare Part-Dieu, 69003 Lyon',
    coordinates: { lat: 45.7640, lng: 4.8357 }
  },
  arrival: {
    city: 'Marseille',
    address: 'Gare Saint-Charles, 13001 Marseille',
    coordinates: { lat: 43.2965, lng: 5.3698 }
  },
  departureDateTime: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), // ✅ Dans 10 jours
  estimatedDuration: 195, // ✅ 3h15 pour Lyon-Marseille
  availableSeats: 2,
  // Pas de pricePerSeat - calcul automatique attendu
  distance: 315, // ✅ Distance Lyon-Marseille
  description: 'Trajet Lyon-Marseille, départ ponctuel. Bonne ambiance garantie !',
  vehicle: {
    brand: 'Peugeot',
    model: '308',
    color: 'Rouge',
    year: 2021
  }
};

// ✅ FONCTIONS UTILITAIRES
const makeRequest = async (method, endpoint, data = null, token = null) => {
  try {
    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` })
      },
      ...(data && { data })
    };

    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return {
      success: false,
      error: error.response?.data || error.message
    };
  }
};

const logStep = (step, description) => {
  console.log(`\n🔹 ÉTAPE ${step}: ${description}`);
  console.log('─'.repeat(50));
};

const logResult = (success, data) => {
  if (success) {
    console.log('✅ SUCCÈS');
    console.log(JSON.stringify(data, null, 2));
  } else {
    console.log('❌ ÉCHEC');
    console.log(JSON.stringify(data, null, 2));
  }
};

// ✅ TESTS COMPLETS CORRIGÉS
const runCompleteUserFlow = async () => {
  console.log('🚀 DÉBUT DES TESTS COMPLETS USER FLOW (VERSION CORRIGÉE)');
  console.log(`📅 Test ID: ${Date.now()}`);
  console.log('═'.repeat(70));

  try {
    // ═══════════════════════════════════════════════════════════
    // 🚗 PARTIE CONDUCTRICE
    // ═══════════════════════════════════════════════════════════
    
    logStep(1, 'Inscription de la conductrice');
    const driverRegister = await makeRequest('POST', '/auth/register', testUsers.driver);
    logResult(driverRegister.success, driverRegister.data || driverRegister.error);
    
    if (!driverRegister.success) throw new Error('Driver registration failed');
    tokens.driver = driverRegister.data.token;
    userData.driver = driverRegister.data.user;

    logStep(2, 'Création du trajet par la conductrice');
    const tripCreate = await makeRequest('POST', '/trips', testTrip, tokens.driver);
    logResult(tripCreate.success, tripCreate.data || tripCreate.error);
    
    if (!tripCreate.success) throw new Error('Trip creation failed');
    tripData = tripCreate.data.trip;

    // ═══════════════════════════════════════════════════════════
    // 👩‍💼 PARTIE PASSAGÈRE
    // ═══════════════════════════════════════════════════════════
    
    logStep(3, 'Inscription de la passagère');
    const passengerRegister = await makeRequest('POST', '/auth/register', testUsers.passenger);
    logResult(passengerRegister.success, passengerRegister.data || passengerRegister.error);
    
    if (!passengerRegister.success) throw new Error('Passenger registration failed');
    tokens.passenger = passengerRegister.data.token;
    userData.passenger = passengerRegister.data.user;

    logStep(4, 'Recherche de trajets par la passagère');
    const searchParams = `?departureCity=Lyon&arrivalCity=Marseille&passengers=1`; // ✅ Nouvelles villes
    const tripSearch = await makeRequest('GET', `/trips/search${searchParams}`, null, tokens.passenger);
    logResult(tripSearch.success, tripSearch.data || tripSearch.error);

    logStep(5, 'Demande de réservation par la passagère');
    const bookingRequest = {
      tripId: tripData.id,
      numberOfSeats: 1,
      message: 'Bonjour Marie ! Je souhaiterais réserver une place pour Marseille. Merci beaucoup !'
    };
    const bookingCreate = await makeRequest('POST', '/bookings', bookingRequest, tokens.passenger);
    logResult(bookingCreate.success, bookingCreate.data || bookingCreate.error);
    
    if (!bookingCreate.success) throw new Error('Booking creation failed');
    bookingData = bookingCreate.data.booking;

    // ✅ SUPPRESSION DE L'ÉTAPE 6 (Double PaymentIntent)
    // Le PaymentIntent est déjà créé automatiquement dans createBooking

    // ═══════════════════════════════════════════════════════════
    // 📊 VÉRIFICATIONS FINALES
    // ═══════════════════════════════════════════════════════════
    
    logStep(6, 'Vérification réservation côté passagère'); // ✅ Renuméroté
    const passengerBookings = await makeRequest('GET', '/bookings?type=passenger', null, tokens.passenger);
    logResult(passengerBookings.success, passengerBookings.data || passengerBookings.error);

    logStep(7, 'Vérification réservation côté conductrice'); // ✅ Renuméroté
    const driverBookings = await makeRequest('GET', '/bookings?type=driver', null, tokens.driver);
    logResult(driverBookings.success, driverBookings.data || driverBookings.error);

    // ═══════════════════════════════════════════════════════════
    // 🎉 RÉSUMÉ FINAL AVEC INSTRUCTIONS
    // ═══════════════════════════════════════════════════════════
    
    console.log('\n🎉 TESTS COMPLETS RÉUSSIS SANS ERREUR !');
    console.log('═'.repeat(70));
    console.log('📊 RÉSUMÉ :');
    console.log(`👩‍🚗 Conductrice : ${userData.driver.profile.displayName} (${userData.driver.email})`);
    console.log(`👩‍💼 Passagère : ${userData.passenger.profile.displayName} (${userData.passenger.email})`);
    console.log(`🚗 Trajet : ${tripData.departure.city} → ${tripData.arrival.city}`);
    console.log(`💳 Réservation : ${bookingData.id}`);
    console.log(`💰 Montant : ${bookingData.totalPrice}€`);
    
    // ✅ RÉCUPÉRER LE PAYMENT INTENT ID DEPUIS LA RÉSERVATION
    if (bookingData.payment && bookingData.payment.stripePaymentIntentId) {
      const paymentIntentId = bookingData.payment.stripePaymentIntentId;
      console.log(`🔑 PaymentIntent : ${paymentIntentId}`);

      console.log('\n🔧 POUR TESTER LE PAIEMENT MANUELLEMENT :');
      console.log('═'.repeat(70));
      console.log('1️⃣ Exécutez cette commande Stripe CLI :');
      console.log(`   stripe payment_intents confirm ${paymentIntentId} --payment-method pm_card_visa`);
      
      console.log('\n2️⃣ Puis confirmez dans notre système :');
      console.log(`   curl -X POST ${BASE_URL}/payments/confirm-trip-payment \\`);
      console.log(`     -H "Content-Type: application/json" \\`);
      console.log(`     -H "Authorization: Bearer ${tokens.passenger}" \\`);
      console.log(`     -d '{"paymentIntentId": "${paymentIntentId}"}'`);

      console.log('\n3️⃣ Vérifiez le résultat :');
      console.log(`   curl -X GET ${BASE_URL}/bookings/${bookingData.id} \\`);
      console.log(`     -H "Authorization: Bearer ${tokens.passenger}"`);
    }

    console.log('\n🎯 STATUT ACTUEL :');
    console.log('✅ Utilisateurs créés avec emails uniques');
    console.log('✅ Trajet Lyon → Marseille créé');
    console.log('✅ Réservation confirmée avec PaymentIntent');
    console.log('✅ Une seule transaction Stripe (plus de doublon)');
    console.log('⏳ Paiement en attente de confirmation');

  } catch (error) {
    console.error('\n❌ ERREUR DANS LE FLOW :', error.message);
    console.error('Stack:', error.stack);
  }
};

// ✅ LANCEMENT DES TESTS
console.log(`🚀 Démarrage du test à ${new Date().toISOString()}`);
runCompleteUserFlow();