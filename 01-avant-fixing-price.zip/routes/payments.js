const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { protect } = require('../middleware/authMiddleware');
const Booking = require('../models/Booking');
const User = require('../models/User');

// ✅ ROUTE 1 : Créer un PaymentIntent pour une réservation
// @desc    Créer un PaymentIntent Stripe
// @route   POST /api/payments/create-payment-intent
// @access  Private
const createPaymentIntent = async (req, res) => {
  try {
    const { bookingId } = req.body;
    console.log('💳 Creating payment intent for booking:', bookingId);

    // Trouver la réservation
    const booking = await Booking.findById(bookingId)
      .populate('trip', 'distance departure arrival')
      .populate('passenger', 'email profile.displayName')
      .populate('driver', 'profile.displayName');

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Vérifier que l'utilisateur est le passager
    if (booking.passenger._id.toString() !== req.user.id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Only the passenger can pay for this booking'
      });
    }

    // Vérifier que la réservation peut être payée
    if (booking.status !== 'confirmed' && booking.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Booking cannot be paid in current status'
      });
    }

    // Créer ou récupérer le PaymentIntent
    let paymentIntent;
    
    if (booking.payment.stripePaymentIntentId) {
      // Récupérer PaymentIntent existant
      console.log('💳 Retrieving existing PaymentIntent:', booking.payment.stripePaymentIntentId);
      paymentIntent = await stripe.paymentIntents.retrieve(booking.payment.stripePaymentIntentId);
      
      // ✅ VÉRIFIER SI BESOIN DE RECRÉER (si annulé ou échoué)
      if (paymentIntent.status === 'canceled' || paymentIntent.status === 'failed') {
        console.log('💳 Previous PaymentIntent failed, creating new one...');
        paymentIntent = null; // Force création d'un nouveau
      }
    }
    
    if (!paymentIntent) {
      // ✅ CRÉER NOUVEAU PAYMENTINTENT AVEC BONNE CONFIG
      console.log('💳 Creating new PaymentIntent...');
      
      // Calculer les montants
      const distance = booking.trip.distance || 100;
      const seats = booking.numberOfSeats || 1;
      const pricePerSeatPerKm = 0.55;
      
      const totalAmount = Math.round(distance * seats * pricePerSeatPerKm * 100); // en centimes
      const commissionRate = 0.20; // 20% commission
      const commissionAmount = Math.round(totalAmount * commissionRate);
      const driverAmount = totalAmount - commissionAmount;

      // Créer ou récupérer le customer Stripe
      let customerId = booking.passenger.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: booking.passenger.email,
          name: booking.passenger.profile.displayName,
          metadata: {
            userId: booking.passenger._id.toString()
          }
        });
        customerId = customer.id;
        
        // Sauvegarder le customer ID
        await User.findByIdAndUpdate(booking.passenger._id, {
          stripeCustomerId: customerId
        });
      }

      // ✅ CRÉER PAYMENTINTENT AVEC CONFIGURATION CORRECTE
      paymentIntent = await stripe.paymentIntents.create({
        amount: totalAmount,
        currency: 'eur',
        customer: customerId,
        description: `Trajet ${booking.trip.departure.city} → ${booking.trip.arrival.city}`,
        // ✅ CONFIGURATION ANTI-REDIRECTION
        automatic_payment_methods: {
          enabled: true,
          allow_redirects: 'never'
        },
        metadata: {
          bookingId: bookingId.toString(),
          tripId: booking.trip._id.toString(),
          passengerId: booking.passenger._id.toString(),
          driverId: booking.driver._id.toString(),
          driverAmount: driverAmount.toString(),
          commissionAmount: commissionAmount.toString(),
          distance: distance.toString(),
          seats: seats.toString(),
          type: 'trip_payment'
        }
      });

      // ✅ SAUVEGARDER LE PAYMENTINTENT DANS LA RÉSERVATION
      booking.payment = {
        status: 'processing',
        stripePaymentIntentId: paymentIntent.id,
        amount: totalAmount,
        currency: 'eur',
        clientSecret: paymentIntent.client_secret,
        requiresPayment: true,
        createdAt: new Date()
      };
      
      await booking.save();
      console.log('✅ PaymentIntent saved to booking');
    }

    res.status(200).json({
      success: true,
      message: 'Payment intent created successfully',
      paymentIntent: {
        id: paymentIntent.id,
        clientSecret: paymentIntent.client_secret,
        amount: paymentIntent.amount,
        currency: paymentIntent.currency,
        status: paymentIntent.status
      },
      booking: {
        id: booking._id,
        trip: {
          departure: booking.trip.departure,
          arrival: booking.trip.arrival
        },
        numberOfSeats: booking.numberOfSeats,
        totalPrice: booking.totalPrice,
        passenger: {
          displayName: booking.passenger.profile.displayName,
          email: booking.passenger.email
        }
      }
    });

  } catch (error) {
    console.error('❌ Create payment intent error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create payment intent',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

// ✅ ROUTE 2 : Confirmer un paiement manuellement
// @desc    Confirmer un paiement réussi
// @route   POST /api/payments/confirm-payment
// @access  Private
const confirmPayment = async (req, res) => {
  try {
    const { bookingId, paymentIntentId } = req.body;

    console.log('✅ Confirming payment for booking:', bookingId, 'PI:', paymentIntentId);

    // Trouver la réservation
    const booking = await Booking.findById(bookingId);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    // Vérifier que l'utilisateur est le passager
    if (booking.passenger.toString() !== req.user.id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized'
      });
    }

    // Vérifier le PaymentIntent avec Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status !== 'succeeded') {
      
      return res.status(400).json({
        success: false,
        message: 'Payment not completed',
        paymentStatus: paymentIntent.status
      });
    }

    // Confirmer le paiement dans notre système
    await booking.confirmPayment();

    console.log('✅ Payment confirmed successfully');

    res.status(200).json({
      success: true,
      message: 'Payment confirmed successfully',
      booking: {
        id: booking._id,
        status: booking.status,
        payment: {
          status: booking.payment.status,
          paidAt: booking.payment.paidAt,
          amount: booking.payment.amount
        }
      }
    });

  } catch (error) {
    console.error('❌ Confirm payment error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to confirm payment',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

// ✅ ROUTE 3 : Historique des paiements utilisateur
// @desc    Obtenir l'historique des paiements
// @route   GET /api/payments/history
// @access  Private
const getPaymentHistory = async (req, res) => {
  try {
    const { type = 'all', status, limit = 20, page = 1 } = req.query;

    console.log('📊 Getting payment history for user:', req.user.id);

    let query = {
      $or: [
        { passenger: req.user.id },
        { driver: req.user.id }
      ]
    };

    // Filtrer par type
    if (type === 'passenger') {
      query = { passenger: req.user.id };
    } else if (type === 'driver') {
      query = { driver: req.user.id };
    }

    // Filtrer par statut paiement
    if (status) {
      query['payment.status'] = status;
    }

    const bookings = await Booking.find(query)
      .populate('trip', 'departure arrival departureDateTime distance')
      .populate('passenger', 'profile.displayName profile.avatar')
      .populate('driver', 'profile.displayName profile.avatar')
      .sort({ 'payment.paidAt': -1, createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Booking.countDocuments(query);

    // Formater les données
    const payments = bookings.map(booking => ({
      id: booking._id,
      trip: {
        departure: booking.trip.departure,
        arrival: booking.trip.arrival,
        departureDateTime: booking.trip.departureDateTime,
        distance: booking.trip.distance
      },
      passenger: booking.passenger,
      driver: booking.driver,
      numberOfSeats: booking.numberOfSeats,
      totalPrice: booking.totalPrice,
      status: booking.status,
      payment: {
        status: booking.payment.status,
        amount: booking.payment.amount,
        currency: booking.payment.currency,
        paidAt: booking.payment.paidAt,
        refundedAt: booking.payment.refundedAt,
        refundAmount: booking.payment.refundAmount,
        commission: booking.payment.commission,
        driverPayout: booking.payment.driverPayout
      },
      createdAt: booking.createdAt
    }));

    res.status(200).json({
      success: true,
      count: payments.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit)),
      payments
    });

  } catch (error) {
    console.error('❌ Get payment history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get payment history'
    });
  }
};

// ✅ ROUTE 4 : Statistiques paiements
// @desc    Obtenir les statistiques de paiement
// @route   GET /api/payments/stats
// @access  Private
const getPaymentStats = async (req, res) => {
  try {
    const userId = req.user.id;

    console.log('📊 Getting payment stats for user:', userId);

    // Stats passager
    const passengerStats = await Booking.aggregate([
      { $match: { passenger: userId } },
      {
        $group: {
          _id: '$payment.status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$payment.amount' }
        }
      }
    ]);

    // Stats conductrice
    const driverStats = await Booking.aggregate([
      { $match: { driver: userId } },
      {
        $group: {
          _id: '$payment.status',
          count: { $sum: 1 },
          totalEarnings: { $sum: '$payment.commission.driverAmount' }
        }
      }
    ]);

    // Virements en attente
    const pendingPayouts = await Booking.find({
      driver: userId,
      'payment.driverPayout.status': { $in: ['pending', 'scheduled'] }
    }).select('payment.driverPayout numberOfSeats totalPrice');

    // Formater les stats
    const formatStats = (stats) => {
      const result = {};
      stats.forEach(stat => {
        result[stat._id] = {
          count: stat.count,
          amount: stat.totalAmount || stat.totalEarnings || 0
        };
      });
      return result;
    };

    res.status(200).json({
      success: true,
      stats: {
        asPassenger: formatStats(passengerStats),
        asDriver: formatStats(driverStats),
        pendingPayouts: {
          count: pendingPayouts.length,
          totalAmount: pendingPayouts.reduce((sum, booking) => 
            sum + (booking.payment.driverPayout.amount || 0), 0
          )
        }
      }
    });

  } catch (error) {
    console.error('❌ Get payment stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get payment statistics'
    });
  }
};

// Routes protégées
router.use(protect);

router.post('/create-payment-intent', createPaymentIntent);
router.post('/confirm-payment', confirmPayment);
router.get('/history', getPaymentHistory);
router.get('/stats', getPaymentStats);

// ✅ MAINTENANT vous pouvez décommenter
const {
  createSubscription,
  cancelSubscription,
  getSubscriptionStatus,
  createTripPayment,        // ✅ Maintenant disponible
  confirmTripPayment        // ✅ Maintenant disponible
} = require('../controllers/paymentController');

// Routes abonnements (GARDER)
router.post('/create-subscription', createSubscription);
router.post('/cancel-subscription', cancelSubscription);
router.get('/subscription-status', getSubscriptionStatus);

// ✅ DÉCOMMENTER ces routes
router.post('/create-trip-payment', createTripPayment);
router.post('/confirm-trip-payment', confirmTripPayment);

module.exports = router;