const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  // Informations de base
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  
  password: {
    type: String,
    required: function() {
      return !this.googleId; // Mot de passe requis seulement si pas de Google OAuth
    },
    minlength: [6, 'Password must be at least 6 characters']
  },
  
  // Google OAuth
  googleId: {
    type: String,
    sparse: true // Permet les valeurs null multiples
  },
  
  // Profil utilisateur
  profile: {
    displayName: {
      type: String,
      required: [true, 'Display name is required'],
      trim: true,
      maxlength: [50, 'Display name cannot exceed 50 characters']
    },
    
    firstName: {
      type: String,
      trim: true,
      maxlength: [30, 'First name cannot exceed 30 characters']
    },
    
    lastName: {
      type: String,
      trim: true,
      maxlength: [30, 'Last name cannot exceed 30 characters']
    },
    
    gender: {
      type: String,
      required: [true, 'Gender is required'],
      enum: ['femme'], // Seulement 'femme' autorisé
      lowercase: true
    },
    
    phone: {
      type: String,
      validate: {
        validator: function(v) {
          // Accepter vide/null ou un format valide
          return !v || /^[\+]?[0-9]{10,15}$/.test(v);
        },
        message: 'Please provide a valid phone number (10-15 digits, optional + prefix)'
      }
    },
    
    avatar: {
      type: String, // URL de l'image
      default: null
    },
    
    bio: {
      type: String,
      maxlength: [500, 'Bio cannot exceed 500 characters']
    },
    
    dateOfBirth: {
      type: Date,
      validate: {
        validator: function(date) {
          const age = (new Date() - date) / (365.25 * 24 * 60 * 60 * 1000);
          return age >= 18; // Minimum 18 ans
        },
        message: 'You must be at least 18 years old'
      }
    }
  },
  
  // Vérifications et sécurité
  verification: {
    isEmailVerified: {
      type: Boolean,
      default: false
    },
    emailVerificationToken: String,
    emailVerificationExpires: Date,
    
    isPhoneVerified: {
      type: Boolean,
      default: false
    },
    
    isIdentityVerified: {
      type: Boolean,
      default: false
    }
  },
  
  // Abonnement
  subscription: {
    isActive: {
      type: Boolean,
      default: false
    },
    stripeCustomerId: String,
    stripePriceId: String,
    stripeSubscriptionId: String,
    currentPeriodStart: Date,
    currentPeriodEnd: Date,
    status: {
      type: String,
      enum: ['active', 'inactive', 'canceled', 'past_due'],
      default: 'inactive'
    }
  },
  
  // Statistiques et réputation
  stats: {
    totalTrajets: {
      type: Number,
      default: 0
    },
    totalKilometers: {
      type: Number,
      default: 0
    },
    rating: {
      average: {
        type: Number,
        default: 0,
        min: 0,
        max: 5
      },
      count: {
        type: Number,
        default: 0
      }
    }
  },
  
  // Préférences
  preferences: {
    allowSmoking: {
      type: Boolean,
      default: false
    },
    allowPets: {
      type: Boolean,
      default: false
    },
    musicPreference: {
      type: String,
      enum: ['none', 'low', 'medium', 'high'],
      default: 'medium'
    },
    chatLevel: {
      type: String,
      enum: ['quiet', 'normal', 'talkative'],
      default: 'normal'
    }
  },
  
  // Sécurité
  security: {
    lastLogin: Date,
    loginAttempts: {
      type: Number,
      default: 0
    },
    lockUntil: Date,
    passwordResetToken: String,
    passwordResetExpires: Date,
    twoFactorEnabled: {
      type: Boolean,
      default: false
    }
  },
  
  // Status du compte
  status: {
    type: String,
    enum: ['active', 'suspended', 'banned', 'deleted'],
    default: 'active'
  },
  
  // Métadonnées
  metadata: {
    registrationSource: {
      type: String,
      enum: ['web', 'mobile', 'google'],
      default: 'web'
    },
    lastActive: {
      type: Date,
      default: Date.now
    },
    ipAddress: String,
    userAgent: String
  }
}, {
  timestamps: true, // Ajoute createdAt et updatedAt automatiquement
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Index pour les performances
userSchema.index({ email: 1 });
userSchema.index({ googleId: 1 });
userSchema.index({ 'profile.displayName': 1 });
userSchema.index({ status: 1 });

// Virtual pour l'âge
userSchema.virtual('age').get(function() {
  if (!this.profile.dateOfBirth) return null;
  return Math.floor((new Date() - this.profile.dateOfBirth) / (365.25 * 24 * 60 * 60 * 1000));
});

// Virtual pour le nom complet
userSchema.virtual('fullName').get(function() {
  return `${this.profile.firstName || ''} ${this.profile.lastName || ''}`.trim();
});

// Middleware pre-save pour hasher le mot de passe
userSchema.pre('save', async function(next) {
  // Seulement hasher si le mot de passe a été modifié
  if (!this.isModified('password')) return next();
  
  try {
    // Hasher le mot de passe
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Méthode pour comparer les mots de passe
userSchema.methods.comparePassword = async function(candidatePassword) {
  if (!this.password) return false;
  return await bcrypt.compare(candidatePassword, this.password);
};

// Méthode pour générer un token JWT
userSchema.methods.generateAuthToken = function() {
  const jwt = require('jsonwebtoken');
  return jwt.sign(
    { 
      userId: this._id,
      email: this.email,
      role: 'user'
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE || '7d' }
  );
};

// Méthode pour obtenir les infos publiques
userSchema.methods.getPublicProfile = function() {
  return {
    id: this._id,
    displayName: this.profile.displayName,
    avatar: this.profile.avatar,
    rating: this.stats.rating,
    totalTrajets: this.stats.totalTrajets,
    isVerified: this.verification.isIdentityVerified,
    memberSince: this.createdAt
  };
};

// Méthode pour vérifier si le compte est verrouillé
userSchema.methods.isLocked = function() {
  return !!(this.security.lockUntil && this.security.lockUntil > Date.now());
};

// Méthode pour incrémenter les tentatives de connexion
userSchema.methods.incLoginAttempts = function() {
  // Si on a un verrou précédent et qu'il a expiré, on remet à zéro
  if (this.security.lockUntil && this.security.lockUntil < Date.now()) {
    return this.updateOne({
      $unset: { 'security.lockUntil': 1 },
      $set: { 'security.loginAttempts': 1 }
    });
  }
  
  const updates = { $inc: { 'security.loginAttempts': 1 } };
  
  // Verrouiller le compte après 5 tentatives pour 2 heures
  if (this.security.loginAttempts + 1 >= 5 && !this.isLocked()) {
    updates.$set = { 'security.lockUntil': Date.now() + 2 * 60 * 60 * 1000 }; // 2 heures
  }
  
  return this.updateOne(updates);
};

// Méthode pour réinitialiser les tentatives de connexion
userSchema.methods.resetLoginAttempts = function() {
  return this.updateOne({
    $unset: {
      'security.loginAttempts': 1,
      'security.lockUntil': 1
    }
  });
};

module.exports = mongoose.model('User', userSchema);